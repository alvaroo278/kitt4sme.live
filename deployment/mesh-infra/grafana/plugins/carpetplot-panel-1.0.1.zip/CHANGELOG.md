# Changelog

## v0.3.1
- Solucionado problema de renderización cuando la query es muy rápida.
- Simplificados los tipos de Table Query Format
- Valores numéricos se redondean con dos decimales
- Eliminadas variables innecesarias: format y rounded.
- Eliminadas funciones no usadas en data_formatter

## v0.3.0

- Solucionado problema en la creación de nuevos mapas.
- Solucionado problema al ocultar puntos en el mapa.
- El filtrado de puntos solo estará disponible en mapas con dos o más datasources.
- Añadida una nueva opción en Table Query Format,  "Orion-app", creado para la aplicación y que visualiza tanto puntos con la localización en latitud y longitud como dentro de un objeto FIWARE.
- Los controles de zoom se ocultan a través de una opción.
- La leyenda se oculta automáticamente al elegir Type of Data "Point (Circle or Icon)".

## v0.2.3

- Mejorado el proceso de arranque para mostrar el mapa antes de tener datos.
- Implementado popup lateral izquierdo y mejorado el cambio entre popup.
- Mejorada la selección de dispositivo sobre el mapa.
